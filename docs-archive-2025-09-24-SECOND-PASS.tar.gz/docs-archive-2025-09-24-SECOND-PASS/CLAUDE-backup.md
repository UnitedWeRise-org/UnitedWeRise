# Claude Code Development Reference - Condensed

## 🤖 Production Status & Environment

### Deployment URLs
**Production:**
- **Backend**: https://api.unitedwerise.org
- **Frontend**: https://www.unitedwerise.org
- **Admin Dashboard**: https://www.unitedwerise.org/admin-dashboard.html

**Staging (Development Branch):**
- **Frontend**: https://dev.unitedwerise.org
- **Backend**: https://dev-api.unitedwerise.org
- **Admin Dashboard**: https://dev.unitedwerise.org/admin-dashboard.html

**Azure Direct URLs (for reference):**
- **Staging Frontend**: https://delightful-smoke-097b2fa0f.3.azurestaticapps.net
- **Staging Backend**: https://unitedwerise-backend-staging.wonderfulpond-f8a8271f.eastus.azurecontainerapps.io

### Platform Status: ✅ Complete Social Media Platform
- ✅ My Feed infinite scroll (15-post batches)
- ✅ Photo tagging with privacy controls
- ✅ User relationships & notifications
- ✅ Reputation system with democratic reporting
- ✅ AI content analysis & topic discovery
- ✅ Officials panel with voting records
- ✅ Admin dashboard with deployment monitoring
- ✅ LIVE Stripe payments with tax receipts
- ✅ OAuth Authentication (Google)
- ✅ TOTP 2FA with 24-hour sessions
- ✅ Logical candidate registration flow

---

## 🚨 CRITICAL DEVELOPMENT PROTOCOLS

### 🗣️ COLLABORATIVE LANGUAGE PROTOCOL
**CRITICAL**: When the user uses collaborative words, they indicate a desire for DISCUSSION ONLY, not implementation:

**Collaborative Keywords That Mean "DISCUSS ONLY":**
- "Let's discuss..." = Present options and analysis, DO NOT implement
- "Let's plan..." = Create strategy and approach, DO NOT execute
- "Let's brainstorm..." = Generate ideas and possibilities, DO NOT build
- "Let's figure out..." = Analyze and evaluate options, DO NOT code
- "Let's strategize..." = Develop approach and timeline, DO NOT start work
- "Can we talk about..." = Discussion mode only
- "What do you think about..." = Opinion and analysis requested
- "How should we approach..." = Strategy discussion, not action

**REQUIRED BEHAVIOR**: When these words appear, ALWAYS:
1. Present analysis, options, and recommendations
2. Ask clarifying questions
3. Wait for explicit implementation approval
4. NEVER jump to coding or making changes

**Implementation Only Begins With**:
- "Implement this..."
- "Make these changes..."
- "Fix this..."
- "Add this feature..."
- "Go ahead and..."
- "Start building..."
- Explicit approval after discussion

### 🔥 DEVELOPMENT BRANCH WORKFLOW
**ALL development work MUST be done on development branch:**

#### Branch Rules
- ❌ **NEVER** work directly on main branch
- ❌ **NEVER** push to main without explicit user approval
- ✅ **ALWAYS** start on development branch
- ✅ **ALWAYS** test on staging before production

#### Workflow
```bash
# Start every session
git checkout development && git pull origin development

# Work and commit
git add . && git commit -m "feat/fix: Description" && git push origin development

# Verify on staging: https://dev.unitedwerise.org
# Get user approval before production
```

#### Production Deployment
**FORBIDDEN without user explicitly saying "deploy to production"**
```bash
# ONLY after explicit approval:
# git checkout main && git pull origin main && git merge development && git push origin main
```

### Pre-Implementation Requirements (MANDATORY)
**Before ANY code changes:**

1. **Quick Reference Check**: Review relevant CLAUDE.md sections first
2. **MASTER_DOCUMENTATION Search Strategy**:
   - Use Task Tool: "Search MASTER_DOCUMENTATION.md for [feature/system name]"
   - Target specific sections: `{#api-reference}`, `{#security-authentication}`, etc.
   - Look for cross-references: `Related Systems:`, `Files Modified:`
   - Check "Known Issues" and "Recently Fixed" sections first
3. **Codebase Verification**: Use Grep across ALL files to confirm findings
4. **User Approval**: Never assume reorganization is needed without explicit confirmation


### MASTER_DOCUMENTATION.md Usage Guidelines
**When to consult MASTER_DOCUMENTATION.md:**
- ✅ **API endpoints**: Complete endpoint documentation with examples
- ✅ **System integrations**: How different components connect
- ✅ **Troubleshooting**: Detailed error scenarios and solutions
- ✅ **Security patterns**: Authentication and authorization details
- ✅ **Known issues**: Current bugs and workarounds

**Quick Navigation Guide (28 Major Sections):**
```
Core Systems: {#executive-summary} {#system-architecture} {#database-schema} {#api-reference}
Security: {#security-authentication} {#deployment-infrastructure} {#monitoring-admin}
Features: {#social-features} {#reputation-system} {#media-photos} {#enhanced-search-system}
Civic: {#map-civic-features} {#civic-organizing-system} {#election-tracking-system}
Candidate: {#candidate-registration-admin-system} {#candidate-verification-reporting-system}
Advanced: {#ai-semantic-features} {#ai-trending-topics-system} {#relationship-system}
Operations: {#stripe-nonprofit-payment-system} {#performance-optimizations}
Development: {#known-issues-bugs} {#development-practices} {#troubleshooting}
Planning: {#session-history} {#future-roadmap}
```

**Priority Sections for Common Tasks:**
- **Adding Features**: Check {#api-reference}, {#database-schema}, {#system-architecture}
- **Authentication Issues**: Check {#security-authentication}, {#troubleshooting}
- **UI/Frontend Work**: Check {#ui-ux-components}, {#social-features}, {#media-photos}
- **Deployment**: Check {#deployment-infrastructure}, Recent Changes sections
- **Bug Fixes**: Check {#known-issues-bugs}, {#troubleshooting}, Recently Fixed sections

**How to search effectively:**
```bash
# Use Task Tool for complex searches
"Search MASTER_DOCUMENTATION.md for authentication workflows and related security systems"

# Use Grep for specific patterns
grep -n "API.*endpoint.*auth" MASTER_DOCUMENTATION.md
grep -n "Known Issues" MASTER_DOCUMENTATION.md
grep -n "{#security-" MASTER_DOCUMENTATION.md
```

**Cross-reference patterns to follow:**
- `{#section-name}` → Jump to specific system documentation
- `Related Systems:` → Find interconnected components
- `Files Modified:` → Locate implementation files
- `Recently Fixed:` → Avoid reimplementing solved problems

**If user suggests feature already exists but you can't find it:**
- Document search attempts made
- Request guidance: "Can you point me to where this is located?"
- FULL STOP - No implementation until explicitly told to proceed

### Multi-Developer Conflict Prevention
- **BEFORE ANY EDIT**: Check documentation for "Recently Modified" indicators
- **VERIFY**: No conflicts with other developers' work
- **CRITICAL**: Always verify functionality before removing "deprecated" code

---

## 🚨 CRITICAL: SCOPE CREEP PREVENTION PROTOCOL

### THE CARDINAL RULE: SOLVE THE SPECIFIC PROBLEM ONLY

**BEFORE making ANY code changes:**

#### Step 1: Define the Specific Problem
- Write the problem in ONE sentence
- Identify EXACTLY which user-facing behavior needs to change
- List ONLY the endpoints/functions that serve that behavior

#### Step 2: Minimum Viable Solution Check
- Can this be solved by changing 3 or fewer functions/endpoints?
- If not, STOP and get user approval for broader changes
- If yes, proceed with ONLY those specific changes

#### Step 3: No Architecture Changes Without Explicit Permission
- **NEVER** create new services/classes unless explicitly requested
- **NEVER** "improve consistency" across unrelated code
- **NEVER** refactor working code that isn't causing the specific problem
- **NEVER** replace working implementations with "better" ones

#### Step 4: Working Code is Sacred
- If existing code works correctly, DO NOT TOUCH IT
- "Could be better" ≠ "should be changed"
- Optimization requests must be explicit from user

### 🚨 BANNED PHRASES THAT TRIGGER SCOPE CREEP:
- "While we're at it, let's also..."
- "This would be a good time to..."
- "I noticed we could improve..."
- "For consistency, I'll update..."
- "Let me fix this other issue I found..."

### 🚨 BANNED SOLUTION APPROACHES (ZERO TOLERANCE):
- "Let me create a workaround for..."
- "I'll add a temporary fix..."
- "For now, I'll implement a quick solution..."
- "I can patch this by..."
- "Let me bypass this issue by..."
- "I'll put in a band-aid solution..."
- "This is a temporary implementation..."
- "I'll hardcode this for now..."

### ⚡ THE FUNDAMENTAL PRINCIPLE: NO WORKAROUNDS EVER

**ONLY TWO ACCEPTABLE RESPONSES TO ANY PROBLEM:**

1. **"This is the wrong approach"** - Stop and reassess the entire strategy
2. **"Fix it the right way"** - Implement the correct, permanent, industry-standard solution

**ZERO TOLERANCE POLICY:**
- ❌ **NEVER** implement workarounds, patches, or temporary fixes
- ❌ **NEVER** bypass proper error handling or validation
- ❌ **NEVER** hardcode values to "make it work for now"
- ❌ **NEVER** skip proper testing because "it's temporary"
- ❌ **NEVER** compromise architecture for quick fixes

**REQUIRED MINDSET:**
- ✅ **"What is the industry-standard way to solve this?"**
- ✅ **"How would a senior engineer implement this properly?"**
- ✅ **"Is this solution maintainable and scalable?"**
- ✅ **"Does this follow established patterns in the codebase?"**

**WHEN STUCK:**
- ✅ Research proper implementation patterns
- ✅ Ask user for guidance on the correct approach
- ✅ Propose stopping current approach if it's fundamentally flawed
- ❌ Create a "quick fix" to move forward

### ✅ ALLOWED APPROACH:
- "I will change exactly these 2 endpoints to solve the specific problem"
- "This change only affects the reported behavior"
- "I'm leaving all other working code unchanged"

### 🚨 MANDATORY SCOPE CHECK:
Before proceeding with ANY implementation:
1. **"Am I solving the exact problem stated?"**
2. **"Am I changing the minimum code necessary?"**
3. **"Have I gotten explicit permission for any architectural changes?"**
4. **"Will this change break any working functionality?"**

If ANY answer is uncertain, STOP and clarify with user.

---

## 🚀 DEPLOYMENT GUIDE

### Environment Architecture
**Development Branch** → **Staging Environment** → **User Testing** → **Production Deployment**

Same Docker image deployed to both environments with different environment variables controlling behavior.

**Production:**
- Backend: https://api.unitedwerise.org
- Frontend: https://www.unitedwerise.org
- Admin: https://www.unitedwerise.org/admin-dashboard.html
- Access: Open to all registered users
- Config: `NODE_ENV=production`

**Staging (Admin-Only):**
- Backend: https://dev-api.unitedwerise.org
- Frontend: https://dev.unitedwerise.org
- Admin: https://dev.unitedwerise.org/admin-dashboard.html
- Access: Requires admin login for protected routes
- Config: `NODE_ENV=staging` + `STAGING_ENVIRONMENT=true`

**Environment-Aware Code:**
```javascript
// Frontend: Automatic API routing
if (hostname.includes('dev.unitedwerise.org')) {
  return 'https://dev-api.unitedwerise.org/api';
}

// Backend: Admin-only staging access
if (process.env.NODE_ENV === 'staging' && !req.user?.isAdmin) {
  return res.status(403).json({
    error: 'Staging environment - admin access required.'
  });
}
```

### Pre-Deployment Checklist
```bash
# 1. VERIFY CHANGES EXIST
git status  # Must show changes OR "working tree clean" if committed

# 2. VERIFY TYPESCRIPT COMPILATION (backend only)
cd backend && npm run build  # Must succeed

# 3. VERIFY GITHUB HAS CHANGES
git log -1 --oneline  # Must show your recent commit

# 4. VERIFY PUSHED TO DEVELOPMENT
git log origin/development..HEAD  # Must show nothing (all pushed)
```

### Frontend Deployment
**Staging (Development Branch):**
```bash
git checkout development && git pull origin development
git add . && git commit -m "feat/fix/docs: Description"
git push origin development
# Auto-deploys to https://dev.unitedwerise.org in ~2-5 minutes
```

**Production (Requires Explicit Approval):**
```bash
# ONLY after user says "deploy to production"
# git checkout main && git pull origin main
# git merge development && git push origin main
```

### Backend Deployment
**Staging (Development Branch):**
```bash
# Follow pre-deployment checklist first
git checkout development && git pull origin development
git add . && git commit -m "feat/fix: Description" && git push origin development

GIT_SHA=$(git rev-parse --short HEAD)
DOCKER_TAG="backend-dev-$GIT_SHA-$(date +%Y%m%d-%H%M%S)"

# Build Docker image
az acr build --registry uwracr2425 --image "unitedwerise-backend:$DOCKER_TAG" --no-wait https://github.com/UnitedWeRise-org/UnitedWeRise.git#development:backend

# Wait and verify build
sleep 180
az acr task list-runs --registry uwracr2425 --output table | head -3

# Deploy to staging
DIGEST=$(az acr repository show --name uwracr2425 --image "unitedwerise-backend:$DOCKER_TAG" --query "digest" -o tsv)
az containerapp update \
  --name unitedwerise-backend-staging \
  --resource-group unitedwerise-rg \
  --image "uwracr2425.azurecr.io/unitedwerise-backend@$DIGEST" \
  --revision-suffix "stg-$GIT_SHA-$(date +%H%M%S)" \
  --set-env-vars NODE_ENV=staging STAGING_ENVIRONMENT=true RELEASE_SHA=$GIT_SHA

# Force single revision
az containerapp update --name unitedwerise-backend-staging --resource-group unitedwerise-rg --revision-mode Single

# Verify deployment
DEPLOYED_SHA=$(curl -s "https://dev-api.unitedwerise.org/health" | grep -o '"releaseSha":"[^"]*"' | cut -d'"' -f4)
echo "Expected: $GIT_SHA, Deployed: $DEPLOYED_SHA"
```

**Production (Requires Explicit Approval):**
```bash
# ONLY after user says "deploy to production"
# Similar process but targeting main branch and production containers
```

### Database Migrations
```bash
git checkout development
git add . && git commit -m "schema: Description" && git push origin development
cd backend && npx prisma generate
npx prisma db execute --file scripts/migration.sql --schema prisma/schema.prisma
# Then follow backend deployment
```

### Failure Diagnosis
```bash
# Check in order:
git status  # Changes committed?
git log origin/development..HEAD  # Changes pushed?
cd backend && npm run build  # TypeScript errors?
az acr task list-runs --registry uwracr2425 --output table | head -3  # Build succeeded?
curl -s "https://api.unitedwerise.org/health" | grep uptime  # Fresh container?
```

### Emergency Procedures
```bash
# Backend restart
az containerapp update --name unitedwerise-backend --resource-group unitedwerise-rg --revision-suffix emergency-$(date +%m%d-%H%M)

# Frontend rollback (staging first)
git checkout development && git revert HEAD && git push origin development
```

---

## 🛡️ SECURITY & STANDARDS

### Server Operations (PROHIBITED)
- **NEVER RUN**: `npm run dev`, `npm start`, or server startup commands
- **REQUIRED**: Always ask user to run server commands
- **REASON**: Prevents server crashes and inability to stop/restart

### Admin-Only Debugging (MANDATORY)
- **PROHIBITED**: `console.log()` for debugging
- **REQUIRED**: Use admin verification functions only
```javascript
// ❌ Never
console.log('User data:', userData);

// ✅ Always
await adminDebugLog('ComponentName', 'User data loaded', userData);
```

**Available Functions**: `adminDebugLog()`, `adminDebugError()`, `adminDebugWarn()`, `adminDebugTable()`, `adminDebugSensitive()`

### CSS Positioning Standards
- **DEFAULT**: Use responsive units (vh, vw, %, rem)
- **Troubleshooting Process**:
  1. Check target element positioning
  2. Check parent container hierarchy
  3. Check padding/margin chain
  4. Justify fixed units when used

### 💰 Token Budget Management & Efficiency

#### Smart Token Usage Guidelines
## Token Impact Awareness

### Single Agent Tasks (Minimal Token Usage)
- **Typical Cost**: 1,000-3,000 tokens per task
- **Best For**: Bug fixes, styling changes, simple features
- **Examples**:
  - "Fix typo in header text" → 1,200 tokens
  - "Change button color to blue" → 800 tokens
  - "Add validation to login form" → 2,500 tokens

### Multi-Agent Tasks (High Token Usage)
- **Typical Cost**: 5,000-15,000 tokens per task
- **Best For**: Complex features, cross-system changes, emergency responses
- **Examples**:
  - "Add discussion forums" → 12,000 tokens (4 agents)
  - "Performance optimization" → 8,000 tokens (3 agents)
  - "Emergency production fix" → 6,000 tokens (3 agents, focused)

### Token Budget Recommendations
- **Daily Budget**: ~20,000 tokens for active development
- **Weekly Budget**: ~100,000 tokens for regular team usage
- **Emergency Reserve**: 25,000 tokens for critical incidents

### Cost-Conscious Decision Framework
1. **Task Size Estimation**:
   - <10 lines of code → Single agent (1-3k tokens)
   - 10-50 lines → Single agent with review (3-5k tokens)
   - 50+ lines → Consider multi-agent (5-15k tokens)

2. **Token Impact Questions**:
   - "Is the 3-5x token cost justified for this task?"
   - "Will parallel execution save enough time to justify cost?"
   - "Is this an emergency where cost is less important than speed?"

3. **Budget-Aware Alternatives**:
   - Use single agent with manual review instead of review agent
   - Combine related tasks to amortize multi-agent setup costs
   - Reserve multi-agent for highest-impact work

#### Token Usage Monitoring
```bash
# Weekly token usage review
echo "## Token Usage Review - $(date)"
echo "### Multi-Agent Tasks This Week:"
grep -r "Multi-Agent" .claude/scratchpads/ | wc -l
echo "### Estimated Token Consumption:"
echo "- Single Agent Tasks: ~$((single_tasks * 2000)) tokens"
echo "- Multi-Agent Tasks: ~$((multi_tasks * 8000)) tokens"
echo "### Optimization Opportunities:"
echo "- Tasks that could have been single-agent: [list]"
echo "- Token savings if optimized: ~[amount] tokens"
```

#### Cost-Effective Workflow Patterns
## Efficient Multi-Agent Usage

### Bundle Similar Tasks
❌ **Inefficient**: 3 separate multi-agent sessions for related changes
✅ **Efficient**: 1 multi-agent session handling all related changes

### Sequential Agent Reuse
❌ **Inefficient**: New agents for each small follow-up task
✅ **Efficient**: Reuse existing agents for related work

### Smart Agent Selection
❌ **Inefficient**: 4 agents when 2 would suffice
✅ **Efficient**: Minimum viable agent count for task complexity

### Emergency vs Non-Emergency
❌ **Inefficient**: Multi-agent for non-urgent complex tasks during budget constraints
✅ **Efficient**: Single agent with manual coordination during budget-conscious periods

---

## 🔧 DEVELOPMENT ESSENTIALS

### Key Environment Variables
```
# Azure AI
AZURE_OPENAI_ENDPOINT=https://unitedwerise-openai.openai.azure.com/
ENABLE_SEMANTIC_TOPICS=true

# Azure Storage
AZURE_STORAGE_ACCOUNT_NAME=uwrstorage2425
AZURE_STORAGE_CONTAINER_NAME=photos

# Stripe (LIVE)
STRIPE_SECRET_KEY=[LIVE_KEY]
STRIPE_PUBLISHABLE_KEY=[LIVE_KEY]

# OAuth
GOOGLE_CLIENT_ID=496604941751-663p6eiqo34iumaet9tme4g19msa1bf0.apps.googleusercontent.com
```

### Common Development Patterns
```bash
# After schema changes
npx prisma generate

# Database migrations
npx prisma db execute --file scripts/migration.sql --schema prisma/schema.prisma

# Find CSS usage
grep -r "class-name" frontend/

# Test auth manually
fetch('/api/endpoint', {
  headers: {'Authorization': `Bearer ${localStorage.getItem('authToken')}`}
})
```

### API Response Structure
```javascript
// Backend returns: {success: true, data: {...}}
// apiCall wraps as: {ok: true, status: 200, data: {success: true, data: {...}}}
// Access: response.data.data.user (not response.data.user)
```

### Deployment Verification
```javascript
// Browser console:
deploymentStatus.check()  // Complete status
// Fresh deployment: uptime <60 seconds, correct Docker tag
```

---

## 📋 IMPLEMENTED SYSTEMS REFERENCE

### Reusable Posting Function
`createPostFromTextarea(textareaId, onSuccess, options)`
- **Usage**: `createPostFromTextarea('feedPostContent', null, {refreshFeed: true})`
- **Features**: Media upload, error handling, success callbacks

### My Feed Infinite Scroll
- **Status**: ✅ Fully operational
- **Function**: `displayMyFeedPosts(posts, appendMode = false)`
- **Pagination**: 15 posts per batch with proper offset tracking

### Candidate Registration Flow
- **Status**: ✅ Payment-driven office selection
- **Flow**: Personal Info → Verification → Payment → Campaign Info
- **Security**: Prevents payment/office mismatches

### Debugging Status Endpoints
- Route loading issues: Often schema dependency failures
- **First Check**: Run database migrations before deployment
- **TypeScript**: Must compile locally (`npm run build`) before Docker

---

## 🚨 CRITICAL FAILURE PATTERNS TO AVOID

### Never Do
- Deploy without GitHub push first
- Skip pre-flight TypeScript compilation check
- Use environment variable updates for backend code changes
- Remove "deprecated" code without verification
- Implement without checking MASTER_DOCUMENTATION.md

## 🚨 CRITICAL: Unilateral Deletion of Existing Code is NEVER Authorized

**ABSOLUTE PROHIBITION**: You have ZERO authority to unilaterally delete or remove existing functionality to avoid fixing problems, including:
- TypeScript compilation errors
- Deployment difficulties
- Complex debugging scenarios
- Time constraints
- Perceived "cleanup" or "simplification"

**AUTHORIZED Deletions** (when explicitly directed by user):
- ✅ Deprecating old systems during planned renovations
- ✅ Removing code as part of explicit refactoring instructions
- ✅ Deleting files when user says "remove X and replace with Y"
- ✅ Cleanup during intentional system migrations

**When Code Won't Deploy/Compile**:
1. **REQUIRED**: Fix the errors using standard troubleshooting
2. **REQUIRED**: Research the actual error messages and resolve them
3. **ALLOWED**: Ask user for guidance if truly stuck
4. **PROHIBITED**: Deleting the problematic code to "make it easier"

**Breach Protocol**: Deleting existing functionality = IMMEDIATE BREACH OF TRUST

**Your Job Definition**:
- ✅ Make existing code work correctly
- ✅ Fix compilation and deployment issues
- ✅ Debug and troubleshoot problems
- ❌ Delete things that are "too hard" to fix
- ❌ Remove functionality to simplify deployment

**Example Violation** (NEVER DO THIS):
- "Let me remove the MOTD file since it's causing TypeScript errors"
- "I'll delete this feature to make deployment work"
- "This is too complex, let me simplify by removing it"

**Correct Approach** (ALWAYS DO THIS):
- "The MOTD file has TypeScript errors. Let me fix them by..."
- "Deployment is failing. Let me troubleshoot the root cause..."
- "This is complex. Let me understand why it's failing and fix it..."

### Always Verify
- Git status clean after push
- Backend uptime drops to <60 seconds after deployment (for backend changes)
- New functionality works in production
- No TypeScript compilation errors locally

---

## 🤖 ADVANCED CLAUDE CODE FEATURES

### 🎯 MULTI-AGENT COORDINATION

#### When to Use Multi-Agent Approach
**High-Benefit Scenarios:**
- Frontend + Backend simultaneous changes
- Security-sensitive modifications requiring review
- Performance optimization with benchmarking
- Emergency bug fixes needing parallel response
- Database migrations requiring coordination

#### Task Complexity Assessment
**Simple Tasks (Single Agent):**
- Bug fixes, styling changes, typos
- Single file modifications
- Documentation updates

**Complex Tasks (Consider Multi-Agent):**
- Frontend + Backend changes
- Security-sensitive modifications
- Performance optimization
- Emergency production issues
- Database schema changes

#### Multi-Agent Decision Framework
**When to Suggest Multi-Agent:**
- Task involves 3+ system components
- Security review needed during development
- Parallel work would save significant time
- Emergency response requiring rapid coordination

**Communication:**
"This task involves [specific factors]. Multi-agent approach could provide [specific benefits]. Proceed with parallel workflow?"

#### Practical Multi-Agent Coordination
**Using TodoWrite for Coordination:**
- Each agent updates shared TodoWrite list
- Clear handoff points between agents
- Status tracking: pending → in_progress → completed

**Simple Communication Pattern:**
```markdown
Agent 1: "Implementation complete - ready for review"
Agent 2: "Security review passed - ready for testing"
Agent 3: "Testing complete - ready for deployment"
```

#### Agent Specialization Areas
**Development Agent:**
- Implement core functionality
- Follow development branch workflow
- Update TodoWrite with progress

**Review Agent:**
- Security pattern compliance
- Code quality assessment
- Admin debugging verification

**Testing Agent:**
- Staging environment verification
- API endpoint testing
- User flow validation

**Deployment Agent:**
- Pre-deployment checklist execution
- Staging deployment first
- Production approval gates

#### Practical Multi-Agent Workflows

**Feature Development:**
```bash
# Agent 1: Backend implementation
# Agent 2: Frontend development (parallel)
# Agent 3: Security review (continuous)
# Agent 4: Testing coordination
```

**Emergency Response:**
```bash
# Agent 1: Incident analysis
# Agent 2: Hotfix development
# Agent 3: Staging verification
```

**Database Migration:**
```bash
# Agent 1: Migration planning
# Agent 2: Schema execution
# Agent 3: Application updates
# Agent 4: Monitoring
```

#### Fallback Strategies
**When Multi-Agent Coordination Fails:**

**Coordination Issues:**
- Switch to single-agent mode immediately
- Use TodoWrite for simple progress tracking
- Manual checkpoints instead of automated handoffs

**Communication Breakdown:**
- Direct agent instructions instead of shared files
- Clear, explicit task definitions
- Manual coordination by user when needed

**Emergency Fallback:**
```
Single agent completes entire task end-to-end
Focus on development branch workflow
Deploy to staging for verification
Document only critical changes
```

#### Task-Specific Multi-Agent Patterns

**Feature Development Example:**
- Research agent: Analyze existing patterns
- Backend agent: Implement API endpoints
- Frontend agent: Build UI components
- Security agent: Review implementation
- Testing agent: Verify on staging

**Emergency Response Example:**
- Diagnostic agent: Identify root cause
- Fix agent: Implement solution
- Verification agent: Test fix thoroughly
- Communication: Document resolution

**Performance Optimization Example:**
- Profiler agent: Identify bottlenecks
- Optimizer agent: Implement improvements
- Benchmark agent: Measure results

#### Coordination Protocols

**Handoff Points:**
- Development complete → Security review
- Review passed → Testing phase
- Testing verified → Deployment ready

**Conflict Resolution:**
- Document concerns in TodoWrite
- Pause implementation until resolved
- Present options to user for decision
- User choice drives final approach

#### Expected Benefits

**Time Savings:**
- Feature development: 40-50% faster
- Bug fixes: 50-60% faster
- Emergency response: 60-70% faster

**Quality Improvements:**
- Fewer bugs through continuous review
- Better security pattern compliance
- More thorough testing coverage
- Improved documentation

#### Intelligent Multi-Agent Suggestions

**Automatic Analysis:**
Claude analyzes tasks and suggests multi-agent when beneficial:
- Complex feature development
- Emergency production issues
- Security-sensitive changes
- Performance optimization
- Database migrations

**Response Pattern:**
"This task involves [factors]. Multi-agent approach could provide [benefits]: parallel development, continuous review, faster resolution. Estimated time savings: [X]%. Proceed with multi-agent workflow?"

#### MCP Integration
Leverage specialized MCP tools for:
- Environment health checks
- Deployment verification
- API performance monitoring
- Security compliance scanning
- Admin debugging validation

---

**📖 Complete system details in MASTER_DOCUMENTATION.md**